package constants;
//To assign permanent role to the project
public enum Role {
    ADMIN, FACULTY, STUDENT;
}
